# Amlogic

This project is for Amlogic SoC devices

## Links

* http://linux-meson.com

## Useful debug commands

* `cat /sys/kernel/debug/cec/cec0/status`
* `cat /sys/kernel/debug/clk/clk_summary`
* `cat /sys/class/drm/card0-HDMI-A-1/status`
* `hexdump -C /sys/class/drm/card0-HDMI-A-1/edid`
* `edid-decode /sys/class/drm/card0-HDMI-A-1/edid`
* `cat /sys/kernel/debug/dma_buf/bufinfo`
